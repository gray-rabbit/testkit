import{r}from"./singletons-12a22614.js";const n=r,g=s;async function s(o,t){return n.goto(o,t,[])}export{g};
